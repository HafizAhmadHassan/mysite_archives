from rest_framework.renderers import JSONRenderer

class TransformerRenderer(JSONRenderer):
    def render(self, data, accepted_media_type=None, renderer_context=None):
        # Handle paginated response
        if isinstance(data, dict) and 'results' in data:
            meta = {
                'total': data.get('count'),
                'page': data.get('page'),
                'page_size': data.get('page_size'),
                'total_pages': data.get('total_pages'),
                'has_next': data.get('has_next'),
                'has_prev': data.get('has_prev'),
                'next_page': data.get('next_page'),
                'prev_page': data.get('prev_page')
            }
            return super().render({
                'meta': meta,
                'data': data.get('results', [])
            }, accepted_media_type, renderer_context)

        # Non-paginated fallback
        return super().render({
            'meta': {},
            'data': data
        }, accepted_media_type, renderer_context)

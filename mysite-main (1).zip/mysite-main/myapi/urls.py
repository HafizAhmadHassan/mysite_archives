from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import MachineViewSet, MachinedetailViewSet, JoinedMachineViewSet, JoinedMachineGPSViewSet, UserViewSet, GPSViewSet, LogViewSet, CombinedPLCView, AlarmViewSet
from .views import MessageViewSet, JoinedMachineGPSViewSet2  # Remove MessageCreateView import
from rest_framework_simplejwt.views import TokenObtainPairView
from .views import login_api, logout_api, CustomerViewSet,list_roles
from .views import PlcWriteCreateView, CustomTokenRefreshView, TokenRefreshView

router = DefaultRouter()
router.register(r'log', LogViewSet, basename='log')
router.register(r'gps', GPSViewSet,basename='gps')
router.register(r'user', UserViewSet,basename='users')
router.register(r'machines', MachineViewSet)
router.register(r'machinedetails', MachinedetailViewSet)
router.register(r'joined-machines', JoinedMachineViewSet, basename='joinedmachines')
#router.register(r'joined-machines-gps1', JoinedMachineGPSViewSet, basename='joinedmachinesgps')
router.register(r'message', MessageViewSet, basename='message')
router.register(r'alarms', AlarmViewSet)
router.register(r'customers', CustomerViewSet, basename='customer-prefixes')

router.register(r'joined-machines-gps', JoinedMachineGPSViewSet2, basename='joinedmachinegps')

urlpatterns = [
    path('api/auth/login/', login_api, name='login'),
    path('api/auth/logout/', logout_api, name='logout'),
    path('plc/', CombinedPLCView.as_view(), name='plc-list'),
    path('plc/<int:pk>/', CombinedPLCView.as_view(), name='plc-detail'),
    path('roles/', list_roles, name='list-roles'),
    path('plc_write/', PlcWriteCreateView.as_view(), name='plc-write'),
  # Get access + refresh tokens
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),

    # Refresh access token using refresh token
    path('api/auth/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('', include(router.urls)),
]
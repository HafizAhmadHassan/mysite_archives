from django.shortcuts import render
from rest_framework import viewsets
from rest_framework.views import APIView,status
from rest_framework import generics
from rest_framework.permissions import AllowAny
from rest_framework.authentication import SessionAuthentication

from kgnWebApp.models import Machine,Machine_detail,GPS,Log,PLCData, PLCIO, PLCStatus,Message, Alarm,plc_write
from .serializers import MachineSerializer, MachinedetailSerializer,JoinedMachineSerializer, JoinedMachineWithGPS_Serializer,GPSSerializer,UserSerializer,LogSerializer,CombinedPLCSerializer,MessageSerializer, AlarmSerializer,plcwriteSerializer
from rest_framework.response import Response
from django.contrib.auth.models import User
from .pagination import CustomMetaPagination
from django.http import JsonResponse
from rest_framework import viewsets
from rest_framework.authentication import SessionAuthentication

from django.contrib.auth import get_user_model
from rest_framework import viewsets, filters
from django_filters.rest_framework import DjangoFilterBackend

from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from rest_framework.permissions import IsAuthenticated

from django.contrib.auth.models import Group

from rest_framework.generics import CreateAPIView


# myapi/views.py
from rest_framework_simplejwt.views import TokenRefreshView
from .serializers import CustomTokenRefreshSerializer
 
class CombinedPLCView(APIView):
    
    def get(self, request, pk=None):
        try:
            if pk:
                plc_data = PLCData.objects.get(pk=pk)
                plc_io = PLCIO.objects.get(pk=pk)
                plc_status = PLCStatus.objects.get(pk=pk)

                combined_instance = {
                    'plc_data': plc_data,
                    'plc_io': plc_io,
                    'plc_status': plc_status
                }
                serializer = CombinedPLCSerializer(combined_instance)
                return Response(serializer.data)

            else:
                plc_data_qs = PLCData.objects.all().order_by('id')
                plc_io_qs = PLCIO.objects.all().order_by('id')
                plc_status_qs = PLCStatus.objects.all().order_by('id')

                combined_data = []
                for data, io, status_obj in zip(plc_data_qs, plc_io_qs, plc_status_qs):
                    combined_data.append({
                        'plc_data': data,
                        'plc_io': io,
                        'plc_status': status_obj
                    })

                # Apply pagination manually
                paginator= CustomMetaPagination()
                paginated_data = paginator.paginate_queryset(combined_data, request, view=self)

                serializer = CombinedPLCSerializer(paginated_data, many=True)
                return paginator.get_paginated_response(serializer.data)

        except (PLCIO.DoesNotExist, PLCData.DoesNotExist, PLCStatus.DoesNotExist):
            return Response(
                {"error": "PLC data not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class LogViewSet(viewsets.ModelViewSet):
    serializer_class = LogSerializer
    pagination_class = CustomMetaPagination

    filter_backends = [filters.SearchFilter, DjangoFilterBackend]  
    search_fields = ['machine_ip', 'customer_Name', 'name_alarm', 'code_alarm']  
    filterset_fields = ['customer_Name']

    def get_queryset(self):
        queryset = Log.objects.exclude(machine_ip="-----").order_by('-id')
        user = self.request.user
        if user.first_name.strip().lower() in ['kgn', 'admin']:
            return queryset
        return queryset.filter(customer_Name=user.first_name.strip())


class GPSViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = GPSSerializer
    pagination_class = CustomMetaPagination
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['customer_Name']  

    def get_queryset(self):
        user_first_name = self.request.user.first_name.strip().lower()
        if user_first_name in ['kgn', 'admin']:
            return GPS.objects.all()
        else:
            return GPS.objects.none()  # No access for others
    

    
class UserViewSet(viewsets.ReadOnlyModelViewSet):  # safer: only GET
    serializer_class = UserSerializer
    pagination_class = CustomMetaPagination

    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    # Remove 'first_name' from filterset_fields if using custom param
    filterset_fields = []  
    search_fields = ['first_name']  # still supports partial search on first_name

    def get_queryset(self):
        user_first_name = self.request.user.first_name.strip().lower()
        if user_first_name in ['kgn', 'admin']:
            queryset = User.objects.all()

            # Custom param mapping: customer_Name → first_name
            customer_name = self.request.query_params.get('customer_Name', None)
            if customer_name:
                queryset = queryset.filter(first_name__iexact=customer_name)

            return queryset
        else:
            return User.objects.none()  # no access for others 

class CustomerViewSet(viewsets.ReadOnlyModelViewSet):  # safer: only GET
    queryset = User.objects.all()
    serializer_class = UserSerializer
    pagination_class = CustomMetaPagination
    

    def list(self, request, *args, **kwargs):
        first_names = self.get_queryset().values_list('first_name', flat=True)

        # Extract prefix before "_" and keep only unique ones
        customers = {
            first_name
            for first_name in first_names
            if first_name is not None
        }

        return Response([{'customers': list(customers)}])

class MachineViewSet(viewsets.ModelViewSet):
    queryset = Machine.objects.all()
    serializer_class = MachineSerializer
    pagination_class = CustomMetaPagination
    
    

class MachinedetailViewSet(viewsets.ModelViewSet):
    queryset = Machine_detail.objects.all()
    serializer_class = MachinedetailSerializer
    pagination_class = CustomMetaPagination



class JoinedMachineViewSet(viewsets.ViewSet):
    pagination_class = CustomMetaPagination
    
    def list(self, request):
        machines = Machine.objects.all()
        details = {d.machine_id: d for d in Machine_detail.objects.all()}  # FK = machine_id

        result = []
        for m in machines:
            d = details.get(m.id)
            if d:
                result.append({
                    # From Machine
                    "id": m.id,
                    "machine_Name": m.machine_Name,
                    "status": m.status,
                    "waste": m.waste,
                    "linux_Version": m.linux_Version,
                    "start_Available": m.start_Available,
                    "end_Available": m.end_Available,
                    "street": m.street,
                    "postal_Code": m.postal_Code,
                    "province": m.province,
                    "city": m.city,
                    "country": m.country,
                    "status_READY_D75_3_7": m.status_READY_D75_3_7,
                    "status_Machine_Blocked": m.status_Machine_Blocked,

                    # From Machine_detail
                    "sheet_Name": d.sheet_Name,
                    "customer_Name": d.customer_Name,
                    "matricola_Bte": d.matricola_Bte,
                    "matricola_Kgn": d.matricola_Kgn,
                    "horus": d.horus,
                    "matricola_Customer": d.matricola_Customer,
                    "ip_Router": d.ip_Router,
                    "certificato": d.certificato,
                    "mac_Address": d.mac_Address,
                    "router": d.router,
                    "sim_provider": d.sim_provider,
                    "sim_Card": d.sim_Card,
                    "pin": d.pin,
                    "codice_GPS": d.codice_GPS,
                    "x_GPS": d.x_GPS,
                    "y_GPS": d.y_GPS,
                    "puk": d.puk,
                    "imei": d.imei,
                    "note": d.note,
                })

        # Apply pagination manually
        paginator = self.pagination_class()
        paginated_result = paginator.paginate_queryset(result, request, view=self)

        serializer = JoinedMachineSerializer(paginated_result, many=True)
        return paginator.get_paginated_response(serializer.data)



class JoinedMachineGPSViewSettest(viewsets.ViewSet):
    pagination_class = CustomMetaPagination
    

    def list(self, request):
        machines = Machine.objects.all()
        details = {d.machine_id: d for d in Machine_detail.objects.all()}
        gps_by_codice = {g.codice: g for g in GPS.objects.all()}

        result = []
        for m in machines:
            d = details.get(m.id)
            if not d:
                continue
            g = gps_by_codice.get(d.codice_GPS)

            result.append({
                # From Machine
                "id": m.id,
                "machine_Name": m.machine_Name,
                "status": m.status,
                "waste": m.waste,
                "linux_Version": m.linux_Version,
                "start_Available": m.start_Available,
                "end_Available": m.end_Available,
                "street": m.street,
                "postal_Code": m.postal_Code,
                "province": m.province,
                "city": m.city,
                "country": m.country,
                "status_READY_D75_3_7": m.status_READY_D75_3_7,
                "status_Machine_Blocked": m.status_Machine_Blocked,

                # From Machine_detail
                "sheet_Name": d.sheet_Name,
                "customer_Name": d.customer_Name,
                "matricola_Bte": d.matricola_Bte,
                "matricola_Kgn": d.matricola_Kgn,
                "ip_Router": d.ip_Router,
                "note": d.note,
                "codice_GPS": d.codice_GPS,

                # From GPS (if exists)
                "gps_x": g.gps_x if g else '',
                "gps_y": g.gps_y if g else '',
                "municipility": g.municipility if g else '',
                "address": g.address if g else '',
            })

        # Apply pagination
        paginator = self.pagination_class()
        paginated_result = paginator.paginate_queryset(result, request, view=self)

        serializer = JoinedMachineWithGPS_Serializer(paginated_result, many=True)
        return paginator.get_paginated_response(serializer.data)





class JoinedMachineGPSViewSet(viewsets.ViewSet):
    pagination_class = CustomMetaPagination
    

    def list(self, request):      
        
        user_first_name = request.user.first_name
        customer_name_filter = request.query_params.get('customer_Name', '').strip().lower()
        print(customer_name_filter)
        # Fetch data
        
        machines = Machine.objects.all()

        if user_first_name.lower() in ['kgn', 'admin']:
            details = {d.machine_id: d for d in Machine_detail.objects.all()}

            if customer_name_filter:
                print("I m here")
                filtered_details = Machine_detail.objects.filter(customer_Name=customer_name_filter)
                details = {d.machine_id: d for d in filtered_details}
            else:
                details = {d.machine_id: d for d in Machine_detail.objects.all()}
            
        else:
            filtered_details = Machine_detail.objects.filter(customer_Name=user_first_name)
            details = {d.machine_id: d for d in filtered_details}

       

        gps_by_codice = {g.codice: g for g in GPS.objects.all()}
        
       
        data = []
        for m in machines:
            d = details.get(m.id)
            if not d:
                continue
            g = gps_by_codice.get(d.codice_GPS)

            data.append({
                "id": m.id,
                "machine_Name": m.machine_Name,
                "status": m.status,
                "waste": m.waste,
                "linux_Version": m.linux_Version,
                "start_Available": m.start_Available,
                "end_Available": m.end_Available,
                "street": m.street,
                "postal_Code": m.postal_Code,
                "province": m.province,
                "city": m.city,
                "country": m.country,
                "status_READY_D75_3_7": m.status_READY_D75_3_7,
                "status_Machine_Blocked": m.status_Machine_Blocked,
                "sheet_Name": d.sheet_Name,
                "customer_Name": d.customer_Name,
                "matricola_Bte": d.matricola_Bte,
                "matricola_Kgn": d.matricola_Kgn,
                "ip_Router": d.ip_Router,
                "note": d.note,
                "codice_GPS": d.codice_GPS,
                "gps_x": g.gps_x if g else '',
                "gps_y": g.gps_y if g else '',
                "municipility": g.municipility if g else '',
                "address": g.address if g else '',
            })

        # Handle ?all=true — return all without pagination
        if request.query_params.get('all', '').lower() == 'true':
            serializer = JoinedMachineWithGPS_Serializer(data, many=True)
            return Response({
                "meta": {
                    "total": len(data),
                    "page": 1,
                    "page_size": len(data),
                    "total_pages": 1,
                    "has_next": False,
                    "has_prev": False,
                    "next_page": None,
                    "prev_page": None
                },
                "data": serializer.data
            })

        # 🔁 Paginated response
        paginator = CustomMetaPagination()
        page = paginator.paginate_queryset(data, request, view=self)
        serializer = JoinedMachineWithGPS_Serializer(page, many=True)
        return paginator.get_paginated_response(serializer.data)

class AlarmViewSet(viewsets.ModelViewSet):
    
    queryset = Alarm.objects.all()
    serializer_class = AlarmSerializer



class CsrfExemptSessionAuthentication(SessionAuthentication):
    def enforce_csrf(self, request):
        return  # Skip CSRF check for API requests
    

class MessageViewSet(viewsets.ModelViewSet):
    serializer_class = MessageSerializer
    pagination_class = CustomMetaPagination
    
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['customer_Name']

    def get_queryset(self):
        user = self.request.user

        if user.first_name.lower() in ['kgn', 'admin']:
            queryset = Message.objects.all()
        else:
            queryset = Message.objects.filter(customer_Name=user.first_name.strip())

        problema_filter = self.request.query_params.get('problema')
        if problema_filter:
            values = [v.strip() for v in problema_filter.split(",") if v.strip()]
            for val in values:
                queryset = queryset.filter(problema__contains=[val])

        return queryset


class JoinedMachineGPSViewSet2(viewsets.ViewSet):
    pagination_class = CustomMetaPagination

    def get_filtered_details(self, user_first_name, customer_name_filter=None):
        """
        Shared method to get machine_detail filtered based on user.
        """
        if user_first_name.lower() in ['kgn', 'admin']:
            if customer_name_filter:
                return {d.machine_id: d for d in Machine_detail.objects.filter(customer_Name=customer_name_filter)}
            return {d.machine_id: d for d in Machine_detail.objects.all()}
        else:
            return {d.machine_id: d for d in Machine_detail.objects.filter(customer_Name=user_first_name)}

    def list(self, request):
        user_first_name = request.user.first_name.strip()
        customer_name_filter = request.query_params.get('customer_Name', '').strip().lower()

        details = self.get_filtered_details(user_first_name, customer_name_filter)
        gps_by_codice = {g.codice: g for g in GPS.objects.all()}
        machines = Machine.objects.all()

        data = []
        for m in machines:
            d = details.get(m.id)
            if not d:
                continue
            g = gps_by_codice.get(d.codice_GPS)

            data.append({
                "id": m.id,
                "machine_Name": m.machine_Name,
                "status": m.status,
                "waste": m.waste,
                "linux_Version": m.linux_Version,
                "start_Available": m.start_Available,
                "end_Available": m.end_Available,
                "street": m.street,
                "postal_Code": m.postal_Code,
                "province": m.province,
                "city": m.city,
                "country": m.country,
                "status_READY_D75_3_7": m.status_READY_D75_3_7,
                "status_Machine_Blocked": m.status_Machine_Blocked,
                "sheet_Name": d.sheet_Name,
                "customer_Name": d.customer_Name,
                "matricola_Bte": d.matricola_Bte,
                "matricola_Kgn": d.matricola_Kgn,
                "ip_Router": d.ip_Router,
                "note": d.note,
                "codice_GPS": d.codice_GPS,
                "gps_x": g.gps_x if g else '',
                "gps_y": g.gps_y if g else '',
                "municipility": g.municipility if g else '',
                "address": g.address if g else '',
            })

        if request.query_params.get('all', '').lower() == 'true':
            serializer = JoinedMachineWithGPS_Serializer(data, many=True)
            return Response({
                "meta": {
                    "total": len(data),
                    "page": 1,
                    "page_size": len(data),
                    "total_pages": 1,
                    "has_next": False,
                    "has_prev": False,
                    "next_page": None,
                    "prev_page": None
                },
                "data": serializer.data
            })

        paginator = CustomMetaPagination()
        page = paginator.paginate_queryset(data, request, view=self)
        serializer = JoinedMachineWithGPS_Serializer(page, many=True)
        return paginator.get_paginated_response(serializer.data)

    def retrieve(self, request, pk=None):
        """
        Handle GET /api/Joined-Machine-GPS/<pk>/ calls
        """
        try:
            machine = Machine.objects.get(pk=pk)
        except Machine.DoesNotExist:
            return Response({"detail": "Machine not found."}, status=404)

        user_first_name = request.user.first_name.strip()
        details = self.get_filtered_details(user_first_name)

        d = details.get(machine.id)
        if not d:
            return Response({"detail": "Access denied or machine not found."}, status=403)

        g = GPS.objects.filter(codice=d.codice_GPS).first()

        data = {
            "id": machine.id,
            "machine_Name": machine.machine_Name,
            "status": machine.status,
            "waste": machine.waste,
            "linux_Version": machine.linux_Version,
            "start_Available": machine.start_Available,
            "end_Available": machine.end_Available,
            "street": machine.street,
            "postal_Code": machine.postal_Code,
            "province": machine.province,
            "city": machine.city,
            "country": machine.country,
            "status_READY_D75_3_7": machine.status_READY_D75_3_7,
            "status_Machine_Blocked": machine.status_Machine_Blocked,
            "sheet_Name": d.sheet_Name,
            "customer_Name": d.customer_Name,
            "matricola_Bte": d.matricola_Bte,
            "matricola_Kgn": d.matricola_Kgn,
            "ip_Router": d.ip_Router,
            "note": d.note,
            "codice_GPS": d.codice_GPS,
            "gps_x": g.gps_x if g else '',
            "gps_y": g.gps_y if g else '',
            "municipility": g.municipility if g else '',
            "address": g.address if g else '',
        }

        serializer = JoinedMachineWithGPS_Serializer(data)
        return Response(serializer.data)

class PlcWriteCreateView(CreateAPIView):
    queryset = plc_write.objects.all()
    serializer_class = plcwriteSerializer



@api_view(['POST'])
@permission_classes([AllowAny])
def login_api(request):
    """
    Login API that returns JWT tokens
    """
    username = request.data.get('username')
    password = request.data.get('password')
    
    if not username or not password:
        return Response(
            {'error': 'Please provide both username and password'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    user = authenticate(username=username, password=password)
    
    if user is not None:
        if user.is_active:
            refresh = RefreshToken.for_user(user)

            # 🔐 Get user permissions grouped by model
            all_permissions = user.get_all_permissions()
            grouped_permissions = {}

            for perm_str in all_permissions:
                # Format: "app_label.codename"
                app_label, codename = perm_str.split('.')
                if '_' in codename:
                    action, model = codename.split('_', 1)
                    if model not in grouped_permissions:
                        grouped_permissions[model] = []
                    if action not in grouped_permissions[model]:
                        grouped_permissions[model].append(action)

            # 🎯 Get user's group(s) as role(s)
            roles = list(user.groups.values_list('name', flat=True))                  
            if "machine" in grouped_permissions:
                grouped_permissions["joined-machines-gps"] = grouped_permissions["machine"]

            if "plcdata" in grouped_permissions:
                grouped_permissions["plc"]=grouped_permissions["plcdata"]

            
            return Response({
                'access': str(refresh.access_token),
                'refresh': str(refresh),
                'token_type': 'Bearer',
                'user': {
                    'id': user.id,
                    'username': user.username,
                    'email': user.email,
                    'first_name': user.first_name,
                    'last_name': user.last_name,
                    'role': roles[0] if roles else None,  # or use 'roles': roles for all groups
                    'permissions': grouped_permissions
                }
            }, status=status.HTTP_200_OK)
        else:
            return Response(
                {'error': 'Account is disabled'},
                status=status.HTTP_401_UNAUTHORIZED
            )
    else:
        return Response(
            {'error': 'Invalid credentials'},
            status=status.HTTP_401_UNAUTHORIZED
        )



@api_view(['POST'])
@permission_classes([AllowAny])
def refresh_token_api(request):
    """
    Refresh JWT token
    """
    refresh_token = request.data.get('refresh')
    
    if not refresh_token:
        return Response(
            {'error': 'Refresh token is required'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        refresh = RefreshToken(refresh_token)
        access_token = str(refresh.access_token)
        
        return Response({
            'access': access_token,
            'token_type': 'Bearer'
        }, status=status.HTTP_200_OK)
        
    except Exception as e:
        return Response(
            {'error': 'Invalid refresh token'},
            status=status.HTTP_401_UNAUTHORIZED
        )

@api_view(['POST'])
def logout_api(request):
    """
    Logout API (optional - blacklist token)
    """
    try:
        refresh_token = request.data.get('refresh')
        if refresh_token:
            token = RefreshToken(refresh_token)
            token.blacklist()
        
        return Response({
            'message': 'Successfully logged out'
        }, status=status.HTTP_200_OK)
        
    except Exception as e:
        return Response(
            {'error': 'Invalid token'},
            status=status.HTTP_400_BAD_REQUEST
        )


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_roles(request):

    roles = Group.objects.values_list('name', flat=True)
    return Response({
        "roles": list(roles)
    })




class CustomTokenRefreshView(TokenRefreshView):
    serializer_class = CustomTokenRefreshSerializer

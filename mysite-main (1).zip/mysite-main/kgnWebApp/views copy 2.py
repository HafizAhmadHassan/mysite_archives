from django.http import HttpResponse
from django.template import loader

from .models import Machine
#def show_all_machine():
    
#   machine = Machine.objects.values_list("machine_Name",flat=True)
#   output="\n".join([m_text for m_text in machine])
#   print(output)
    

#    machine = Machine.objects.values_list("machine_Name")
#    output=" - ".join([str(m_text[0]) for m_text in machine])
#    print(output)
    

   
"""
def index(request):
    machine = Machine.objects.values_list("machine_Name",flat=True)

    template = loader.get_template("kgnWebApp/index.html")
    context ={
        "machine" : machine,
    }
    return HttpResponse(template.render(context,request))
"""




# views.py
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
from .models import Machine
import json
import boto3

# Initialize your Amazon RDS client
client = boto3.client('rds-data', region_name='eu-south-1a', aws_access_key_id='AKIATCMPCKJUQT5LO5FP', aws_secret_access_key='x718Q2FSbRNQST+q/kIxxBpPwoXT4W7GLNhr163t')


def update_amazon_db(request):
    print("Database DatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabaseDatabase")
    data = json.loads(request.body)
    card_key = data.get('card_key')
    new_value = data.get('new_value')
    machine_id = data.get('machine_id')

    try:
        # Example logic to update the Amazon database
        response = client.execute_statement(
            resourceArn='arn:aws:rds:eu-south-1:211290313321:db:database-1',
            secretArn='arn:aws:secretsmanager:eu-south-1:211290313321:secret:kgnsql-N1a3Rq',
            database='KGN_DB',
            sql=f"UPDATE kgnWebApp SET {card_key} = :new_value WHERE id = :machine_id",
            parameters=[
                {'name': 'new_value', 'value': {'stringValue': new_value}},
                {'name': 'machine_id', 'value': {'stringValue': machine_id}}
            ]
        )
        return JsonResponse({'status': 'success', 'message': 'Database updated successfully'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})


def index(request):
    machine = Machine.objects.all()

    template = loader.get_template("kgnWebApp/index.html")
    context ={
        "machines" : machine,
    }
    return HttpResponse(template.render(context,request))

"""
def details(request,machine_id):
    response = "You're looking at the machine %s."
    return HttpResponse(response % machine_id)


def detail(request,machine_id):
  
    machine=Machine.objects.get(pk=machine_id)
    #every alarm has machine id 
    # there is Foreign key machine in Alarm
    print(machine.alarm_set.all(),machine.alarm_set.count())
    alarm = Alarm.objects.get(machine=machine_id)
    print("Attention : Look at the difference behind print does not contain Query Set and Object Insidre")
    print(alarm)
    print(machine.machine_order_set.count())
    machine_orders_counts=machine.machine_order_set.count()

    machine_orders=machine.machine_order_set.all()

    alarm = Alarm.objects.get(machine=machine_id)
    print(alarm)
    alarm_queryset = Alarm.objects.none()
    alarm_queryset |= Alarm.objects.filter(pk=alarm.pk)
    print(alarm_queryset)
    print(machine_orders[0].Pieces)

    context ={
        "machines" : machine,
        "machine_orders": machine_orders,
        "machine_orders_count" : machine_orders_counts,
    }
    template = loader.get_template("kgnWebApp/detail.html")
    
    return HttpResponse(template.render(context,request))

"""


from django.contrib import admin
from django.urls import path,include
from .import views
admin.site.site_header= " KGN Web Portal "
admin.site.site_title= " KGN Portal "
admin.site.index_title= " KGN || Admin Panel"

urlpatterns = [
    path('', views.index, name='index'),
    path('admin/', admin.site.urls),
]

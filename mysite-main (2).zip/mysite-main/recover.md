if data get deleted 

AWS recover the previous snapshot of data (point at the time)
give it master password
if multiple databases are connected change the port 3306 to 3307
add inbound connection to rds and default security all trafic allowed 👍 

make sure in additional configuration when u click modify it is set to public
come back to mysql workbench and add credentials

create data export for the tables deleted .. and modified foreign keys .sql file (self contained file section)
login to original database do data import but remove other super user preveliges

check if something added in column or not

use KGN_DB;
select * from kgnWebApp_machine_detail;

ALTER TABLE kgnWebApp_machine
DROP COLUMN ciao;



SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE kgnWebApp_machine;

SET FOREIGN_KEY_CHECKS = 1;


our master password : yourpasswordkgn or your_password
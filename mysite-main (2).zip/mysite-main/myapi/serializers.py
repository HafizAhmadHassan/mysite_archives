from rest_framework import serializers
from kgnWebApp.models import Machine, Machine_detail,GPS,Log,PLCData, PLCIO, PLCStatus,Message, Alarm,plc_write
from django.contrib.auth.models import User
from rest_framework import serializers

# myapi/serializers.py
from rest_framework_simplejwt.serializers import TokenRefreshSerializer
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework import serializers


class PLCDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = PLCData
        fields = '__all__'

class PLCIOSerializer(serializers.ModelSerializer):
    class Meta:
        model = PLCIO
        fields = '__all__'


# New serializer to match the transformed output
class PLCIOFieldSerializer(serializers.Serializer):
    label = serializers.CharField()
    value = serializers.IntegerField()
    unit = serializers.CharField()

class TransformedPLCSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    plc_io = serializers.DictField(child=PLCIOFieldSerializer())



class PLCStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model = PLCStatus
        fields = '__all__'

# serializers.py (continued)
class CombinedPLCSerializer(serializers.Serializer):
    plc_data = PLCDataSerializer()
    plc_io = PLCIOSerializer()
    plc_status = PLCStatusSerializer()



class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        exclude = ['password']  # This excludes only the password field

class GPSSerializer(serializers.ModelSerializer):
    class Meta:
        model = GPS
        fields = '__all__'


class LogSerializer(serializers.ModelSerializer):
    machine_detail = serializers.SerializerMethodField()
    gps = serializers.SerializerMethodField()

    class Meta:
        model = Log
        fields = '__all__'  # includes all original Log fields
        extra_fields = ['machine_detail', 'gps']  # optional, just for clarity

    def get_machine_detail(self, obj):
        try:
            detail = Machine_detail.objects.filter(ip_Router=obj.machine_ip).first()
            if detail:
                return {
                    'customer_Name': detail.customer_Name,
                    'matricola_Bte': detail.matricola_Bte,
                    'matricola_Kgn': detail.matricola_Kgn,
                    'sheet_Name': detail.sheet_Name,
                    'codice_GPS': detail.codice_GPS,
                    'ip_Router': detail.ip_Router,
                    'note': detail.note,
                }
        except Exception as e:
            print(f"[LogSerializer Error] machine_detail: {e}")
        return None

    def get_gps(self, obj):
        try:
            detail = Machine_detail.objects.filter(ip_Router=obj.machine_ip).first()
            if detail:
                gps = GPS.objects.filter(codice=detail.codice_GPS).first()
                if gps:
                    return {
                        'gps_x': gps.gps_x,
                        'gps_y': gps.gps_y,
                        'municipility': gps.municipility,
                        'address': gps.address,
                        'waste': gps.waste,
                    }
        except Exception as e:
            print(f"[LogSerializer Error] gps: {e}")
        return None

class MachineSerializer(serializers.ModelSerializer):
    class Meta:
        model = Machine
        fields = '__all__'

class MachinedetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Machine_detail
        fields = '__all__'

class JoinedMachineSerializer(serializers.Serializer):
    # From Machine
    id = serializers.IntegerField()
    first_name= serializers.CharField()
    machine_Name = serializers.CharField()
    status = serializers.IntegerField()
    waste = serializers.CharField()
    linux_Version = serializers.CharField()
    start_Available = serializers.DateField()
    end_Available = serializers.DateField()
    street = serializers.CharField()
    postal_Code = serializers.CharField()
    province = serializers.CharField()
    city = serializers.CharField()
    country = serializers.CharField()
    status_READY_D75_3_7 = serializers.BooleanField()
    status_Machine_Blocked = serializers.BooleanField()

    # From Machine_detail
    sheet_Name = serializers.CharField()
    customer_Name = serializers.CharField()
    matricola_Bte = serializers.CharField()
    matricola_Kgn = serializers.CharField()
    horus = serializers.CharField()
    matricola_Customer = serializers.CharField()
    ip_Router = serializers.CharField()
    certificato = serializers.CharField()
    mac_Address = serializers.CharField()
    router = serializers.CharField()
    sim_provider = serializers.CharField()
    sim_Card = serializers.CharField()
    pin = serializers.CharField()
    codice_GPS = serializers.CharField()
    x_GPS = serializers.CharField()
    y_GPS = serializers.CharField()
    puk = serializers.CharField()
    imei = serializers.CharField()
    note = serializers.CharField()


class JoinedMachineWithGPS_Serializer(serializers.Serializer):
    # Machine fields
    id = serializers.IntegerField()
    machine_Name = serializers.CharField()
    status = serializers.IntegerField()
    waste = serializers.CharField()
    linux_Version = serializers.CharField()
    start_Available = serializers.DateField()
    end_Available = serializers.DateField()
    street = serializers.CharField()
    postal_Code = serializers.CharField()
    province = serializers.CharField()
    city = serializers.CharField()
    country = serializers.CharField()
    status_READY_D75_3_7 = serializers.BooleanField()
    status_Machine_Blocked = serializers.BooleanField()

    # Machine_detail fields
    codice_GPS = serializers.CharField()
    sheet_Name = serializers.CharField()
    customer_Name = serializers.CharField()
    matricola_Bte = serializers.CharField()
    matricola_Kgn = serializers.CharField()
    ip_Router = serializers.CharField()
    note = serializers.CharField()

    # GPS fields
    gps_x = serializers.CharField()
    gps_y = serializers.CharField()
    municipility = serializers.CharField()
    address = serializers.CharField()





class AlarmSerializer(serializers.ModelSerializer):
    class Meta:
        model = Alarm
        fields = '__all__'



class MessageSerializer(serializers.ModelSerializer):
    machine_detail = serializers.SerializerMethodField()
    gps = serializers.SerializerMethodField()

    class Meta:
        model = Message
        fields = '__all__'
        extra_fields = ['machine_detail', 'gps']  # optional

    def get_machine_detail(self, obj):
        try:
            detail = Machine_detail.objects.filter(machine_id=obj.machine.id).first()
            if detail:
                return {
                    'customer_Name': detail.customer_Name,
                    'matricola_Bte': detail.matricola_Bte,
                    'matricola_Kgn': detail.matricola_Kgn,
                    'sheet_Name': detail.sheet_Name,
                    'codice_GPS': detail.codice_GPS,
                    'ip_Router': detail.ip_Router,
                    'note': detail.note,
                }
        except Exception as e:
            print(f"[MessageSerializer Error] machine_detail: {e}")
        return None

    def get_gps(self, obj):
        try:
            detail = Machine_detail.objects.filter(machine_id=obj.machine.id).first()
            if detail:
                gps = GPS.objects.filter(codice=detail.codice_GPS).first()
                if gps:
                    return {
                        'gps_x': gps.gps_x,
                        'gps_y': gps.gps_y,
                        'municipility': gps.municipility,
                        'address': gps.address,
                        'waste': gps.waste,
                    }
        except Exception as e:
            print(f"[MessageSerializer Error] gps: {e}")
        return None




class plcwriteSerializer(serializers.ModelSerializer):
    class Meta:
        model = plc_write
        fields = '__all__'





class CustomTokenRefreshSerializer(TokenRefreshSerializer):
    def validate(self, attrs):
        # Standard refresh validation
        data = super().validate(attrs)

        # Get the original refresh token
        refresh = RefreshToken(attrs['refresh'])

        # Create a new refresh token
        new_refresh = RefreshToken.for_user(refresh.access_token.payload['user_id'])

        # Add new refresh token alongside access
        data['refresh'] = str(new_refresh)
        return data

// Add any custom JavaScript here
document.addEventListener("DOMContentLoaded", function () {
    // Example JavaScript functionality can be added here
    console.log("Dashboard loaded");
});

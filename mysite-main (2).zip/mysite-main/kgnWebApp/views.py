from django.http import HttpResponse
from django.template import loader
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.shortcuts import redirect
from django.contrib import messages
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from itertools import zip_longest
import smtplib
from datetime import date
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from django.db.models import Q
from .models import Log,Message
from django.http import JsonResponse
from .models import Machine, PLCData, PLCIO,PLCStatus,AlarmSetting,Log,Machine_detail,GPS,plc_write
import json
import boto3
from django.urls import reverse
from django.shortcuts import render, get_object_or_404
from django.shortcuts import render
from .forms import MachineForm,PLCDataForm,PLCIOForm,PLCStatusForm,Machine_detailForm  # Import the MachineForm
import folium
from folium.plugins import MarkerCluster

from django.shortcuts import render
from django.core.paginator import Paginator
from django.db.models import Q
from .models import Log, Machine_detail, Machine

from django.shortcuts import render
from django.core.paginator import Paginator
from django.db.models import Q
from .models import Log, Machine_detail, Machine


def notifications(request):
    query = request.GET.get('q')
    page_number = request.GET.get('page', 1)

    # Fetch logs based on search
    logs = Log.objects.filter(
        Q(name_alarm__icontains=query) |
        Q(code_alarm__icontains=query) |
        Q(machine_ip__icontains=query) |
        Q(customer_Name__icontains=query)
    ).order_by('-date_and_time') if query else Log.objects.all().order_by('-date_and_time')

    # Extract all unique machine IPs from logs
    machine_ips = list(logs.values_list('machine_ip', flat=True).distinct())

    # Map IP → Machine_detail.id
    ip_to_machine_detail_id = {
        md.ip_Router: md.id
        for md in Machine_detail.objects.filter(ip_Router__in=machine_ips)
    }

    # Fetch machines and build mapping from ID → Machine
    machine_ids = list(ip_to_machine_detail_id.values())
    machine_id_to_machine = {
        m.id: m for m in Machine.objects.filter(id__in=machine_ids)
    }

    # Pair logs only when a valid machine can be resolved
    machine_log_pairs = []
    for log in logs:
        md_id = ip_to_machine_detail_id.get(log.machine_ip)
        machine = machine_id_to_machine.get(md_id)
        if machine:
            machine_log_pairs.append((machine, log))  # only include valid pairs

    # Paginate valid machine-log pairs
    paginator = Paginator(machine_log_pairs, 10)
    page_obj = paginator.get_page(page_number)

    return render(request, 'kgnWebApp/notifications.html', {
        'query': query,
        'page_obj': page_obj,
    })
def notifications3(request):
    query = request.GET.get('q')
    page_number = request.GET.get('page', 1)

    logs = Log.objects.filter(
        Q(name_alarm__icontains=query) |
        Q(code_alarm__icontains=query) |
        Q(machine_ip__icontains=query) |
        Q(customer_Name__icontains=query)
    ).order_by('-date_and_time') if query else Log.objects.all().order_by('-date_and_time')

    machine_ips = list(logs.values_list('machine_ip', flat=True))
    machine_details = Machine_detail.objects.filter(ip_Router__in=machine_ips)
    ip_to_detail_id = {detail.ip_Router: detail.id for detail in machine_details}
    machine_detail_ids = [ip_to_detail_id[ip] for ip in machine_ips if ip in ip_to_detail_id]

    machines = Machine.objects.filter(id__in=machine_detail_ids)
    machines_dict = {machine.id: machine for machine in machines}
    ordered_machine_ids = [machines_dict[mid].id for mid in machine_detail_ids if mid in machines_dict]

    machines_qs = Machine.objects.filter(id__in=ordered_machine_ids)
    machines_dict = {machine.id: machine for machine in machines_qs}
    ordered_machine_objects = [machines_dict[mid] for mid in ordered_machine_ids if mid in machines_dict]

    # If we couldn't find a machine for some log, use None as placeholder
    machine_objects_padded = ordered_machine_objects + [None] * (len(logs) - len(ordered_machine_objects))

    machine_pairs = list(zip(machine_objects_padded, logs))

    paginator = Paginator(machine_pairs, 10)
    page_obj = paginator.get_page(page_number)

    return render(request, 'kgnWebApp/notifications.html', {
        'query': query,
        'page_obj': page_obj,
    })



def notifications2(request):
    query = request.GET.get('q')
    if query:
        logs = Log.objects.filter(
            Q(name_alarm__icontains=query) |
            Q(code_alarm__icontains=query) |
            Q(machine_ip__icontains=query) |
            Q(customer_Name__icontains=query)
        ).order_by('-date_and_time')
    else:
        
        logs = Log.objects.all().order_by('-date_and_time')

        machine_detail_ids = Machine_detail.objects.filter(ip_Router__in=logs.values_list('machine_ip', flat=True)).values_list('id', flat=True)
        #machines = Machine.objects.filter(id__in=machine_detail_ids)

        # Step 1: Get the machine IPs from logs
        machine_ips = list(logs.values_list('machine_ip', flat=True))

        # Step 2: Get Machine_details and build a mapping from ip_Router to id
        machine_details = Machine_detail.objects.filter(ip_Router__in=machine_ips)
        ip_to_detail_id = {detail.ip_Router: detail.id for detail in machine_details}

        # Step 3: Preserve the order based on IPs in logs
        machine_detail_ids = [ip_to_detail_id[ip] for ip in machine_ips if ip in ip_to_detail_id]
        
        # Get Machine objects in this ordered list of IDs
        machines = Machine.objects.filter(id__in=machine_detail_ids)

        # Build a dict so you can access them by ID
        machines_dict = {machine.id: machine for machine in machines}

        # Now order machines according to preserved IDs
        ordered_machine = [machines_dict[mid].id for mid in machine_detail_ids if mid in machines_dict]
        
        ordered_machine_ids = ordered_machine  # e.g., [5, 2, 9, ...]

        # Fetch all Machine objects for those IDs
        machines_qs = Machine.objects.filter(id__in=ordered_machine_ids)

        # Build a dictionary of id → Machine object
        machines_dict = {machine.id : machine for machine in machines_qs}

        # Reorder according to original list
        ordered_machine_objects = [machines_dict[mid] for mid in ordered_machine_ids if mid in machines_dict]

        print(machine_detail_ids)

        
        machine_dict = {machine: log for machine, log in zip(ordered_machine_objects, logs)}
        
    
    return render(request, 'kgnWebApp/notifications.html', {'logs': logs, 'query': query, 'machine_dict':machine_dict })

#def show_all_machine():
    
#   machine = Machine.objects.values_list("machine_Name",flat=True)
#   output="\n".join([m_text for m_text in machine])
#   print(output)
    

#    machine = Machine.objects.values_list("machine_Name")
#    output=" - ".join([str(m_text[0]) for m_text in machine])
#    print(output)

# views.py

# Initialize your Amazon RDS client

client = boto3.client('rds-data', region_name='eu-south-1a', aws_access_key_id='AKIATCMPCKJUQT5LO5FP', aws_secret_access_key='x718Q2FSbRNQST+q/kIxxBpPwoXT4W7GLNhr163t')


@login_required
def update_amazon_db(request):
    print("Database update request received")
    data = json.loads(request.body)
    card_key = data.get('card_key')
    new_value = data.get('new_value')
    machine_id = data.get('machine_id')

    try:
        # Example logic to update the Amazon database
        response = client.execute_statement(
            resourceArn='arn:aws:rds:eu-south-1:211290313321:db:database-1',
            secretArn='arn:aws:secretsmanager:eu-south-1:211290313321:secret:kgnsql-N1a3Rq',
            database='KGN_DB',
            sql=f"UPDATE kgnWebApp SET {card_key} = :new_value WHERE id = :machine_id",
            parameters=[
                {'name': 'new_value', 'value': {'stringValue': new_value}},
                {'name': 'machine_id', 'value': {'stringValue': machine_id}}
            ]
        )
        return JsonResponse({'status': 'success', 'message': 'Database updated successfully'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})

@login_required
def edit_machine(request, machine_id):
    machine = Machine.objects.get(pk=machine_id)
    
    if request.method == 'POST':
        form = MachineForm(request.POST, instance=machine)
        if form.is_valid():
            form.save()
            return redirect('dashboard')  # Redirect to the dashboard after saving
    else:
        form = MachineForm(instance=machine)
    
    return render(request, 'kgnWebApp/edit_machine.html', {'form': form, 'machine': machine,'machine_id':machine_id})




@login_required
def edit_machine_detail(request, machine_id):
    machine_detail = Machine_detail.objects.get(pk=machine_id)
    
    if request.method == 'POST':
        form = Machine_detailForm(request.POST, instance=machine_detail)
        if form.is_valid():
            form.save()
            previous_page = request.session.get('previous_page', f'/kgnWebApp/details/{machine_id}/')
            return redirect(previous_page)  # Redirect to previous page
    else:
        form = Machine_detailForm(instance=machine_detail)
    
    return render(request, 'kgnWebApp/edit_machine_detail.html', {'form': form, 'machine': machine_detail,'machine_id':machine_id})



@login_required
def edit_plcio(request, machine_id):
    plc = PLCIO.objects.get(pk=machine_id)
    
    if request.method == 'POST':
        form = PLCDataForm(request.POST, instance=plc)
        if form.is_valid():
            form.save()
            return redirect('dashboard')  # Redirect to the dashboard after saving
    else:
        form = PLCIOForm(instance=plc)
    
    return render(request, 'kgnWebApp/edit_machine.html', {'form': form, 'machine': plc,'machine_id':machine_id})

@login_required
def edit_plcstatus(request, machine_id):
    plc = PLCStatus.objects.get(pk=machine_id)
    
    if request.method == 'POST':
        form = PLCStatusForm(request.POST, instance=plc)
        if form.is_valid():
            form.save()
            return redirect('dashboard')  # Redirect to the dashboard after saving
    else:
        form = PLCStatusForm(instance=plc)
    
    return render(request, 'kgnWebApp/edit_plcstatus.html', {'form': form, 'machine': plc,'machine_id':machine_id})

@login_required
def edit_plcdata(request, machine_id):
    plc = PLCData.objects.get(pk=machine_id)
    
    if request.method == 'POST':
        form = PLCDataForm(request.POST, instance=plc)
        if form.is_valid():
            form.save()
            return redirect('dashboard')  # Redirect to the dashboard after saving
    else:
        form = PLCDataForm(instance=plc)
    
    return render(request, 'kgnWebApp/edit_plcdata.html', {'form': form, 'machine': plc,'machine_id':machine_id})

@login_required
def machine_details(request, machine_id):

    
    machine = Machine.objects.get(pk=machine_id)
    machine_dict = {field.name.replace('_',' '): getattr(machine, field.name) for field in machine._meta.fields}
    
    machine_deta = Machine_detail.objects.get(pk=machine_id)

 
    machine_dict2 = {field.name.replace('_',' '): getattr(machine_deta, field.name) for field in machine_deta._meta.fields}
    request.session['previous_page'] = request.build_absolute_uri()
    username = request.session.get('username')
    request.session['matricola']= machine_dict2['matricola Kgn']      
    if machine_dict['status Machine Blocked'] == False:
        request.session['status']='Online'
    elif machine_dict['status Machine Blocked'] == True:
        request.session['status']='Offline'

    return render(request, 'kgnWebApp/details.html',{"machine_id": machine_id, "machine_obj": machine_dict, "machine_deta": machine_dict2 , 'Email': username,'matricola_Kgn': machine_dict2.get('matricola Kgn')})



@login_required
def machinestatus(request, machine_id):
    # Fetch the machine object based on the provided machine_id
    username = request.session.get('username')  
    # List of field names to retrieve
    field_names = [ 
        'PULSANTE HMI APERTURA SERRANDA',
        'PULSANTE HMI CHIUSURA SERRANDA',
        'PULSANTE INDIETRO PRESSA D 5 3.1',
        'PULSANTE EMERGENZA INSERITO D401 19.3',
        'PULSANTE RESET MACCHINA D 75 3.2',
        'CESTA IN CARICO D 201 5.7',
        'CESTA IN SCARICO D 201 5.6',
        'CESTA IN SCARICO D 5 3.7',
        'ATTUALE PRESSIONE D301 52',
        'ATTUALE PESO D201 46',
        'SEQUENZA D 5 20',
        'VERSIONE PLC D5 14',
        'CESTA SICUREZZA IN CARICO i4.4'
        ]
    
    field_names2 = {
        # 216 to 219
        'status_HMI_APRI_WHITE_LISTA':"Apri Lista",
        'status_HMI_CHIUDI_LISTA':"Chiudi Lista",
        'status_PULSANTE_HMI_APERTURA_SERRANDA':"Apri Serranda",
        'status_PULSANTE_HMI_CHIUSURA_SERRANDA':"Chiudi Serranda",
        'status_HMI_RST_PESO_AZZERA_PESO':"Azzera Peso",
        'status_HMI_SEND_DATE_INVIO_DATI':"Invia Dati",
        "status_HMI_TARA": " Tara",
        'status_HMI_MANUTENZIONE':" Manutenzione", # 221
        'status_PRESSA_AVANTI_HMI': 'Pressa Avanti',
        "status_PRESSA_INDIETRO_HMI":"Pressa Indietro 2", # this work
        "status_CESTA_IN_SCARICO_HMI" :"Scarica Cesta",
        "status_RETORNO_CESTA_HMI": "Ruota Cesta"
    }
    reversed_dict = {v: k for k, v in field_names2.items()}

    matricola = request.session.get('matricola')
    status = request.session.get('status')

    
    
  

    field_names4 = {
        'status_CESTA_IN_CARICO_D_201_5_7': "Cesto in Carico",
        'status_CESTA_IN_SCARICO_D_201_5_6' : "Cesto in Scarico",
#        'status_CESTA_IN_SCARICO_D_5_3_7' : "Cesto in Scarico 2",
        'status_ATTUALE_PRESSIONE_D301_52':"Pressione bar",
        'status_ATTUALE_PESO_D201_46':"Peso kg",
        'status_SEQUENZA_D_5_20': "Sequenza",
#        'status_VERSIONE_PLC_D5_14': "Versione PLC",
 #       'status_HMI_EMERGENZA':"Attiva Emergenza", #210
        #"plant2_Carico_Ingombrante" : "Carico Ingombrante 2",
        'status_CARICO_INGOMBRANTE':"Carico Ingombrante",
        'status_PRESSA_AVANTI_D_301_14_6':"Pressa Avanti", # 199
        'status_PRESSA_INDIETRO_D_301_14_7' : "Pressa Indietro",
        'status_PULSANTE_INDIETRO_PRESSA_D_5_3_1' : "Pressa Indietro 2",
        #"plant1_Porte_Aperte" : "Porte Aperte 2",
        "status_PORTE_LATERALI_APERTE":"Porte Laterali Aperte", # add porta aperte alarm
        "status_SERRANDA_APERTA_D_101_5_6": "Serranda Aperta",
        "status_SERRANDA_CHIUSA_D_101_5_7": "Serranda Chiusa",
        'status_SERRANDA_SICUREZZA_CHIUSA':"Sicurezza Serranda", #tag 0
        'status_CESTA_SICUREZZA_IN_CARICO':"Sicurezza Cesto" #tag 0



    }


    field_names6 ={

        "plant1_Porte_Aperte" : "Porte Aperte 2",
    }
    # Query the model and retrieve the specified fields
    plcstatus_instance= PLCStatus.objects.get(pk=machine_id)
    plcsdata_instance= PLCData.objects.get(pk=machine_id)


    # Print or use the field values


    # Create a dictionary to hold the values of the specified fields
    """

    message = None
    if request.method == 'POST':
        button_value = request.POST.get('command-button')
        varname = request.POST.get('varname')
        machine_id = request.POST.get('machine_id')
        print("In request ",button_value,"variable :" , varname)
        if button_value in ["0", "1"]:  # Preventing invalid values
            plc_write.objects.create(
            varname=varname,  # Or replace with dynamic logic if needed
            machine_id=machine_id,
            operation=button_value
        )
     """
    if request.method == 'POST':
        button_value = request.POST.get('com1')
        varname = request.POST.get('varname')
        #machine_id = request.POST.get('machine_id')
        if button_value in ["0", "1"]:  # Preventing invalid values
                plc_write.objects.create(
                varname=reversed_dict.get(varname),  # Or replace with dynamic logic if needed
                machine_id=machine_id,
                operation=button_value
            )
            
        print("In request ",button_value,"variable :" , varname,"machine id : ", machine_id)
        return redirect(reverse('machinestatus', args=[machine_id]))

   

    field_values = {field : getattr(plcstatus_instance, 'status_' + field.replace(' ', '_').replace('.', '_')) for field in field_names}
    field_values2 = {msg : getattr(plcstatus_instance, field) for field, msg in field_names2.items()}
    #print(field_values2)
    field_values4 = {msg : getattr(plcstatus_instance, field) for field, msg in field_names4.items()}
    field_values6 = {msg : getattr(plcsdata_instance, field) for field, msg in field_names6.items()}





    return render(request, 'kgnWebApp/machinestatus.html', {'field_values': field_values,'field_values2': field_values2,'field_values4': field_values4, 'field_values6': field_values6, 'machine_id': machine_id,'Email' : username,"status": status, "matricola":matricola})










@login_required
def plcio(request, machine_id):
    # Fetch the machine object based on the provided machine_id

    plc_instance= PLCIO.objects.get(pk=machine_id)
    username = request.session.get('username')
    matricola = request.session.get('matricola')
    status = request.session.get('status')
    # Convert dictionary to a list of key-value pairs
 
    data_list = {field.name.replace('unit_', ' ').replace('_', ' '): str(getattr(plc_instance, field.name.replace('unit','value')) )+  getattr(plc_instance, field.name) for field in plc_instance._meta.fields if field.name.startswith('unit')}


    return render(request, 'kgnWebApp/plcio.html', {'plcio': data_list ,'machine_id': machine_id, 'Email': username, "status": status, "matricola":matricola})

@login_required
def plcdata(request,machine_id):
    # Fetch the machine object based on the provided machine_id
    plc_instance= PLCData.objects.get(pk=machine_id)
    username = request.session.get('username')
    
    matricola = request.session.get('matricola')
    status = request.session.get('status')

    # Convert dictionary to a list of key-value pairs
    data_list = {field.name.replace('plant1_','').replace('plant2_','').replace('roll_Up_','').replace('rotation_Drum_','').replace('pmp_','').replace('hydraulic_','').replace('yv_Fwbw_','').replace('yv_Fwbw_','').replace('yv_Slow_','').replace('_',' '): getattr(plc_instance, field.name) for field in plc_instance._meta.fields}

    return render(request, 'kgnWebApp/plcdata.html', {'plcdata': data_list,'machine_id': machine_id, 'Email' : username, "status": status, "matricola":matricola})


@login_required
def plcstatus(request,machine_id):
    plc_instance= PLCStatus.objects.get(pk=machine_id)
    
    username = request.session.get('username')
    matricola = request.session.get('matricola')
    status = request.session.get('status')

    # Convert dictionary to a list of key-value pairs
    data_list = {field.name.replace('status_','').replace('_',' '): getattr(plc_instance, field.name) for field in plc_instance._meta.fields}

    return render(request, 'kgnWebApp/plcstatus.html', {'plcstatus': data_list,'machine_id': machine_id,'Email': username,"status": status, "matricola":matricola})
 
  
@login_required
def alarmsettings(request):
    alarms = AlarmSetting.objects.all()
    username = request.session.get('username')
    # Get model field names
    fields = AlarmSetting._meta.get_fields()
    field_names = [field.name for field in fields if field.concrete]
    field_verbose_names = [field.verbose_name for field in fields if field.concrete]

    # Convert queryset to a list of dictionaries with field names and values
    alarm_data = []
    for alarm in alarms:
        alarm_dict = {field_name: getattr(alarm, field_name) for field_name in field_names}
        alarm_data.append(alarm_dict)
    
    print(alarm_data)

    return render(request, 'kgnWebApp/alarmsettings.html', {
        'data': alarm_data,
        'Email' : username,
    })


def map_data():
    return 0


@login_required
def dashboard(request):
    username = request.session.get('username', '')  # Default to empty string if not found
    print("Username:", username)

    custm = username.split('_')[0] if '_' in username else username

    try:
        map = folium.Map(location=['45.422954', '11.813733'], zoom_start=5, width='100%', height='500px')
        marker_cluster = MarkerCluster(
            icon_create_function="""
                function(cluster) {
                    return L.divIcon({
                        html: '<div style="background-color: #3A81F1; border-radius: 20px; padding: 5px 10px; color: white; font-weight: bold;">' + cluster.getChildCount() + '</div>',
                        className: 'marker-cluster-custom',
                        iconSize: new L.Point(40, 40)
                    });
                }
            """
        ).add_to(map)
        
        if username.startswith(('admin', 'kgn')):  # More readable way to check multiple conditions
            machine_instances = Machine.objects.all().order_by('id')
            machine_details_instances = Machine_detail.objects.all()


            machine_details_instances = Machine_detail.objects.filter(
                machine_id__in=Machine.objects.values_list('id', flat=True)
            ).order_by('id')

            plcstatus_instances = PLCStatus.objects.all().order_by('id')
            Log_objs = Log.objects.order_by('-id')[:500]
            

            # Loop through machine detail instances
            for md in machine_details_instances:
                gps_qs = GPS.objects.filter(codice=md.codice_GPS)
                machine_qs = Machine.objects.filter(id=md.id)

                if gps_qs.exists() and machine_qs.exists():
                    gps = gps_qs.first()
                    machine = machine_qs.first()

                    popup_html = f"""
                        <b>IP:</b> {md.ip_Router}<br>
                        <b>Matricola:</b> {md.matricola_Kgn}<br>
                        <b>Waste:</b> {machine.waste}<br>
                        <b>Street:</b> {machine.street}
                    """

                    icon_color = 'red' if machine.status_Machine_Blocked else 'green'

                    folium.Marker(
                        location=[gps.gps_x, gps.gps_y],
                        popup=folium.Popup(popup_html, max_width=300),
                        icon=folium.Icon(color=icon_color)
                    ).add_to(marker_cluster)


        else:
            if custm.startswith('ecocen'):
                Log_objs = Log.objects.filter(customer_Name='ecomont').order_by('-id')[:500]
            else:
                Log_objs = Log.objects.filter(customer_Name=custm.lower()).order_by('-id')[:500]
            
            machine_instances = Machine.objects.filter(
                id__in=Machine_detail.objects.filter(customer_Name=custm.lower()).values_list('machine', flat=True)
            ).order_by('id')
            machine_details_instances = Machine_detail.objects.filter(customer_Name=custm.lower()).order_by('id')
            

            for md in machine_details_instances:
                gps_qs = GPS.objects.filter(codice=md.codice_GPS)
                machine_qs = Machine.objects.filter(id=md.id)

                if gps_qs.exists() and machine_qs.exists():
                    gps = gps_qs.first()
                    machine = machine_qs.first()

                    popup_html = f"""
                        <b>IP:</b> {md.ip_Router}<br>
                        <b>Matricola:</b> {md.matricola_Kgn}<br>
                        <b>Waste:</b> {machine.waste}<br>
                        <b>Street:</b> {machine.street}
                    """

                    icon_color = 'red' if machine.status_Machine_Blocked else 'green'

                    folium.Marker(
                        location=[gps.gps_x, gps.gps_y],
                        popup=folium.Popup(popup_html, max_width=300),
                        icon=folium.Icon(color=icon_color)
                    ).add_to(marker_cluster)

        #zipped_data = zip_longest(machine_instances, machine_details_instances)
        print("Dashboard executed.")
        print("Machine instances:", machine_instances)



        email = request.session.get('username', '')

        message = None
        if request.method == 'POST':
            button_value = request.POST.get('status_button')
            button_value2 = request.POST.get('detail_button')
            machine_id = request.POST.get('machine_id')
            print("In request ",button_value)
            if button_value in ["0", "1"]:  # Preventing invalid values
                plc_write.objects.create(
                varname='status_PULSANTE_RESET_MACCHINA_D_75_3_2',  # Or replace with dynamic logic if needed
                machine_id=machine_id,
                operation=button_value
            )
            
            if button_value2 and machine_id:
                print(f"Machine ID: {machine_id}, Button Value: {button_value2}")
                return redirect(reverse('machine_details', args=[machine_id]))
        
        machine_dict = {machine:detail for machine, detail in zip(list(machine_instances), list(machine_details_instances)) }
        #zipped_data = [(machine_instance, machine_detail_instance) 
        #                for machine_instance, machine_detail_instance in zip(machine_instances, machine_details_instances)]
        #print(zipped_data)



        
        map_html = map._repr_html_()  # returns HTML as string
        context = {
            "Email": email,
            "Log_objs": Log_objs,
            "message": message,
            "machine_instances":machine_instances,
            "machine_details_instances":machine_details_instances,
            "machine_dict": machine_dict,
            "map_html": map_html
            #"zipped_data": zipped_data,  # Pass the zipped data to the template

        }

        return render(request, 'kgnWebApp/dashboard.html', context)

    except Exception as e:
        print(f"Error in dashboard: {e}")
        return render(request, 'kgnWebApp/404.html', {"error": "An error occurred while loading the dashboard."})


def ticket_form(request, machine_id):
    machine = Machine.objects.get(id=machine_id)
    machine_details = Machine_detail.objects.get(id=machine_id)
  
    return render(request, 'kgnWebApp/machine_ticket_form.html', {'machine': machine,'machine_details':machine_details })

@login_required
def submit_ticket(request):
    if request.method == 'POST':
        # Extract form data
        problema_list = request.POST.getlist("problema")
        note = request.POST.get('note')
        address = request.POST.get('machine_address')
        matricola = request.POST.get('matricola')
        customer_Name = request.POST.get('customer')
        ip = request.POST.get('ip')
        mid = request.POST.get('mid')
        waste = request.POST.get('waste')
        try:
            
            ticket = Message.objects.create(
            machine_id=mid,
            problema=problema_list,
            open_Description=f"{note}",
            status=1,
            date_Time=datetime.now(),
            customer_Name=customer_Name,
             
        )
            ticket_id = ticket.id
            sender = 'noreplypress@codex4.awsapps.com'
            password = 'KK2gg3nn4-p2025@'
            msg = MIMEMultipart('alternative')
            msg['From'] = sender
            recipient ="assistenzapress@kgn.it"
            msg['To'] = recipient
            msg['Subject'] = f"Notifica Ticket #{ticket_id} - {customer_Name}"

                                    # HTML Email Content with Table for Customer
            content = f'''<html>
                                <body style="font-family: Arial, sans-serif; color: #333;">
                                    <h2 style="color: #2c3e50;">Notifica Ticket</h2>
                                        <table style="border-collapse: collapse; width: 100%;">
                                            <tr style="background-color: #f2f2f2;">
                                                <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Ticket#</th>

                                                <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Problema</th>
                                                <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Messaggio</th>

                                                <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Address</th>
                                                <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Matricola</th>
                                              <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Wate</th>
                                              <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Ip</th>
                                                <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Customer</th>
                                            </tr>
                                            <tr>
                                                <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;"> {ticket_id} </td>
                                                <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;"> {problema_list} </td>
                                                <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">{note}</td>
                                                
                                                <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">{address}</td>
                                                <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">{matricola}</td>
                                                <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">{waste}</td>
                                                <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">{ip}</td>
                                                <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">{customer_Name}</td>

                                            </tr>
                                        </table>
                                </body>
                            </html>'''
            msg.attach(MIMEText(content, 'html'))
            
            with smtplib.SMTP_SSL('smtp.mail.eu-west-1.awsapps.com', 465) as mail:
                mail.login(sender, password)
                mail.sendmail(sender, recipient, msg.as_string())
            
           
            
        except Exception as e:
            print("Email sending failed:", e)
            return redirect(reverse('page_404'))  # You can make a custom error page
        
    return render(request, 'kgnWebApp/email_acknowledgement.html')


@login_required
def close_ticket(request):
    print("Inside Close Ticket")
    if request.method == 'POST':
        print("Inside Close Ticket")
         
        message_id = request.POST.get('message_id')
        message = get_object_or_404(Message, id=message_id)
        message.guanratee_status = request.POST.getlist("warranty")
        message.close_Description = request.POST.get('note')
        message.status = 2  # assuming '2' means closed
        message.save()

    return render(request, 'kgnWebApp/email_acknowledgement.html')

@login_required
def email_acknowledgement(request):
    return render(request, 'kgnWebApp/email_acknowledgement.html')

@login_required
def page_404(request):
    return render(request, 'kgnWebApp/404.html')

@login_required
def page_profile(request):
    email = request.session.get('email')
    username = request.session.get('username')
    context = dict(
            Email=email,
            Username=username,
    )
    return render(request, 'kgnWebApp/profile.html',context)

@login_required
def page_settings(request):
    email = request.session.get('email')
    username = request.session.get('username')
    context = dict(
            Email=email,
            Username=username,
    )
    return render(request, 'kgnWebApp/settings.html',context)

@login_required
def page_reports(request):

    return render(request, 'kgnWebApp/reports.html')

@login_required
def page_users(request):
    user_instances= User.objects.all()

    context = dict(
           
            user_instances=user_instances
    )
    

    return render(request, 'kgnWebApp/users.html',context)

@login_required
def page_tickets(request):
    print("Inside Post1")
    user = request.POST.get('username')
    mach =[]
    mach_det =[]
    if request.method == 'POST':
        print("Inside Post2:", user)
        user = request.POST.get('username')
        if "@" in user:
            print(user)
            user = User.objects.get(email=user)
            user = user.username
        
        if user == 'admin' or user.startswith('kgn'):
            message_instances= Message.objects.all().order_by('-date_Time')
        
        else:
            parts = user.split('_')
            message_instances = Message.objects.filter(customer_Name=parts[0])
        
        for msg in message_instances:
            machine = Machine.objects.get(id=msg.machine_id)
            mach.append(machine)
            machine_details = Machine_detail.objects.get(id=msg.machine_id)
            mach_det.append(machine_details)
        
        print("Message instances :",message_instances)
        combined_data = [
            {'message': msg, 'machine': mach, 'detail': det}
            for msg, mach, det in zip(message_instances, mach, mach_det)
        ]
        if user.startswith('kgn'):
            user='kgn'
        context = {
            "combined_data": combined_data,
            "user":user
        }
        
        

    return render(request, 'kgnWebApp/tickets.html',context)

@login_required
def page_analytics(request):

    return render(request, 'kgnWebApp/analytics.html')


def page_login(request):
    if request.method == 'POST':
        identifier = request.POST['username']  # could be username or email
        password = request.POST['password']
        
        # Try to get the user by email first
        try:
            user_obj = User.objects.get(email=identifier)
            username = user_obj.username
        except User.DoesNotExist:
            username = identifier  # maybe it's a username
        
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            request.session['username'] = user.username
            request.session['email'] = user.email
            return redirect('/kgnWebApp/dash')
        else:
            messages.error(request, 'Invalid username/email or password')

    return render(request, 'kgnWebApp/login.html')


def page_register(request):

    return render(request, 'kgnWebApp/register.html')


def page_logout(request):
    logout(request)
    return redirect('page_login')

def index(request):
    machine = Machine.objects.all()

    template = loader.get_template("kgnWebApp/index.html")
    context ={
        "machines" : machine,
    }
    return HttpResponse(template.render(context,request))

@login_required
def gps(request):

    gpsobjs= GPS.objects.all()
    username = request.session.get('username')

    # Convert dictionary to a list of key-value pairs
 
    context = dict(
            Email=username,
            gpsobjs=gpsobjs
        )

    return render(request, 'kgnWebApp/gps.html', context)


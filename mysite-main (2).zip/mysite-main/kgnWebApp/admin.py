from django.contrib import admin
import subprocess

# Register your models here.
from .models import *
import datetime as dt
from django.db import models 

from django.core.mail import send_mail
import smtplib
import os
from datetime import date, datetime

from django.http import JsonResponse
import pandas as pd
"""
class MachineAdmin(admin.ModelAdmin):
    list_display = ['machine_Name','status','waste', 'city']
    list_editable = ['status']
    list_per_page = 10

"""


import openpyxl

import openpyxl

from django.shortcuts import render, redirect
from django.urls import path

def find_and_modify_string_in_excel(file_path, search_string, sheet_name, new_value):
    # Load the workbook
    workbook = openpyxl.load_workbook(file_path)
    
    # Check if the sheet name is valid
    if sheet_name not in workbook.sheetnames:
        print(f"Invalid sheet name: {sheet_name}. Available sheets are: {', '.join(workbook.sheetnames)}")
        return
    
    # Select the sheet by name
    sheet = workbook[sheet_name]
    
    # Flag to check if any cell was modified
    modified = False
    
    # Iterate through the cells to find the search string
    for row in sheet.iter_rows():
        for cell in row:
            if cell.value and search_string.lower() in str(cell.value).lower():
                print(f"Found '{search_string}' in cell {cell.coordinate}")
                cell.value = new_value  # Modify the cell value
                modified = True
    
    # Save the workbook if any modifications were made
    if modified:
        workbook.save(file_path)
        print(f"Cells containing '{search_string}' have been updated to '{new_value}'")
    else:
        print(f"No cells containing '{search_string}' were found.")





@admin.register(Machine)
class MachineAdmin(admin.ModelAdmin):

    list_display = ['machine_Name','status','waste', 'city']
    list_editable = ['status']
    list_filter = ['status','waste']
    search_fields = ['machine_Name']
    actions =['set_status_to_change']
    #fields = (('start_Available','end_Available'),'status')

    # Start Allow actions to specific users
    
    #https://stackoverflow.com/questions/38329999/permissions-to-django-admin-actions
    #https://docs.djangoproject.com/en/dev/ref/contrib/admin/actions/#conditionally-enabling-or-disabling-actions
    
    # End Allow actions to specific users
    list_per_page = 10

    change_form_template = "admin/change_form3.html"



            
    def get_excel_data(request,machien_id):
        excel_file = 'book3_2.xlsm.xlsm'
        xls = pd.ExcelFile(excel_file)
        
        data = {}
        sheet_name=machien_id
        df = pd.read_excel(excel_file, sheet_name=sheet_name)
        data[sheet_name] = df.to_dict(orient='records')
        
        return JsonResponse(data, safe=False)



    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('check-machine/<int:machine_id>/', self.admin_site.admin_view(self.check_machine_view), name='check_machine'),
        ]
        return custom_urls + urls

    def check_machine_view(self, request, machine_id):

        
        machine = Machine.objects.get(pk=machine_id)

        excel_data = pd.read_excel('book3_2.xlsm',sheet_name='Sheet1')
        # Convert the data to a dictionary for rendering in the template
        

        # Define lists of row indices and column indices
        row_indices = [92, 93, 94 , 91, 90,80,79 ,83, 96,97, 85,98,99,86,87,88]  # Example row indices
        column_indices = [0, 0, 0,0, 0, 0,0, 0, 0,0, 0, 0,0, 0, 0]  # Example column indices
        #90 to 94
        #96 to 99
        #85-88
        #80,83
        list_of_fives = [4 for _ in range(15)]
        # Extract the specified cells
        extracted_cells = excel_data.iloc[row_indices, column_indices]

        extracted_cells2 = excel_data.iloc[row_indices, list_of_fives]

        
        excel_data_dict = extracted_cells.to_dict(orient='records')
        excel_data_dict2 = extracted_cells2.to_dict(orient='records')

        print(excel_data_dict)
        print(excel_data_dict2)

        new_dict_list = [{list(dict1.values())[0]: list(dict2.values())[0]} for dict1, dict2 in zip(excel_data_dict, excel_data_dict2)]

        

        print("Machine: ", machine_id)


        context = dict(
            self.admin_site.each_context(request),
            machine=machine_id,
            cards=new_dict_list,
            back_url=f'/admin/{self.opts.app_label}/{self.opts.model_name}/{machine_id}/change/',

        )
        return render(request, 'admin/check_machine.html', context)


    def response_change(self, request, obj):

        if "_check_machine" in request.POST:
            print("Button Clicked")
            return redirect('admin:check_machine', machine_id=obj.id)
        return super().response_change(request, obj)


    def get_Brand_Name(self, obj):
        return obj.user.email
    
    def set_status_to_change(self,request,queryset):
        count = queryset.update(status=1)
        self.message_user(request,'{} status changed'.format(count))
    set_status_to_change.short_description = 'Select Machines to Active '
    
    # del acrions to drivers
    def get_actions(self, request):
        actions = super(MachineAdmin, self).get_actions(request)
        if request.user.username[0].upper() == "D":
            if "set_status_to_change" in actions:
                del actions["set_status_to_change"]
        return actions


@admin.register(KgnBrand)
class KgnBrandAdmin(admin.ModelAdmin):
    list_display = ['name','volume_Value','volume_Unit']
    list_editable = ['volume_Value','volume_Unit']


@admin.register(GPS)
class GPSAdmin(admin.ModelAdmin):
    list_display = ['codice','waste','address']


@admin.register(PLCIO)
class PLCIOAdmin(admin.ModelAdmin):
    change_form_template = "admin/change_form1.html"

    # if click on save machine change function called
    def response_change(self, request, obj):
        if "_change-signal" in request.POST:
            print("Hassan is here in Response change")
            #print(request.POST)

            matching_names_except_this = self.get_queryset(request).exclude(pk= obj.id)

            #matching_names_except_this = self.get_queryset(request).filter(name=obj.name).exclude(pk=obj.id)
            print(matching_names_except_this)

            match_one=self.get_queryset(request).get(pk=obj.id)

            another_way_match_one= self.get_queryset(request).filter(pk=obj.id).values()

            print("This is Full matched object Name ",match_one)
            #print("Another way match ",another_way_match_one)
            new_val=[]
            for each_obj in another_way_match_one:
                for name,vals in each_obj.items():
                    #print("vals : ",vals)
                    new_val.append(vals)
            id_obj=str(match_one)[len(str(match_one))-1]
            id_obj=new_val[0]

            print("This is matched one id ",id_obj)

            # now changing updating sql query by passing 
            #matching_names_except_this.delete()
            #obj.is_unique = True
            obj.save()
            print(" Data saved Automatically in Amazon")

            print(" Calling mySql_to_CSV to bring change in CSV File without passing id ")
            #self.message_user(request, "This villain is now unique")
            #return HttpResponseRedirect(".")
            print(str(new_val[1:]))
            id_len=len(str(new_val[0]))
            id_len = id_len*(-1)
            print("This is name if Class object",str(match_one)[:id_len-1])
            subprocess.run(['python3', 'mysql_to_csv_v2.py',str(match_one)[:id_len-1],str(new_val[1:]),str(obj.id)])
        return super().response_change(request, obj)

    def save_model(self, request, obj, form, change):
        # Custom logic before saving
        print("Custom save logic before saving")
        if change:  # Check if this is an update (not a new instance)
            # Get the previous instance from the database
            previous_obj = self.get_queryset(request).filter(pk=obj.id).values()
            print("Previous Objects :",previous_obj)
            new_val=[]
            for each_obj in previous_obj:
                for name,vals in each_obj.items():
                    print("names : ", name ," vals : ",vals)
            # Iterate through the fields and check for changes
          
            for field in obj._meta.fields:
                field_name = field.name
                current_value = getattr(obj, field_name)
                previous_value = getattr(self.get_queryset(request).filter(pk=obj.id).first(), field_name)

                if current_value != previous_value:
                    print(f"Field '{field_name}' changed from '{previous_value}' to '{current_value}'")
  
            """
            substring1 = "unit"
            substring2 = "value"

                        for field in obj._meta.fields:
                field_name = field.name
                current_value = getattr(obj, field_name)
                previous_value = getattr(previous_obj, field_name)

                if current_value != previous_value:
                    print(f"Field '{field_name}' changed from '{previous_value}' to '{current_value}'")
                
                if substring1.lower() in field_name.lower():
                    print("1.")
                if substring2.lower() in field_name.lower():
                    print("2.")
            """


        # Call the original save method
        super().save_model(request, obj, form, change)

        # Custom logic after saving

        print("After")


        """

        for field in obj._meta.fields:
            field_name = field.name
            current_value = getattr(obj, field_name)
            previous_value = getattr(previous_obj, field_name)

            if current_value != previous_value:
                print(f"Field '{field_name}' changed from '{previous_value}' to '{current_value}'")
                
            if substring1.lower() in field_name.lower():
                print("1.")
            if substring2.lower() in field_name.lower():
                print("2.")



        
        here
        find_and_modify_string_in_excel('your_excel_file.xlsx', 'python', 'Sheet1', 'new_value')
        
        """
        
        """
        get object id which is modified
        """




 

@admin.register(PLCData)
class PLCDataAdmin(admin.ModelAdmin):
    change_form_template = "admin/change_form1.html"

    def response_change(self, request, obj):
        if "_change-signal" in request.POST:
            print("Hassan is here in Response change")
            #print(request.POST)

            matching_names_except_this = self.get_queryset(request).exclude(pk= obj.id)

            #matching_names_except_this = self.get_queryset(request).filter(name=obj.name).exclude(pk=obj.id)
            print(matching_names_except_this)

            match_one=self.get_queryset(request).get(pk=obj.id)

            another_way_match_one= self.get_queryset(request).filter(pk=obj.id).values()

            print("This is Full matched object Name ",match_one)
            #print("Another way match ",another_way_match_one)
            new_val=[]
            for each_obj in another_way_match_one:
                for name,vals in each_obj.items():
                    #print("vals : ",vals)
                    new_val.append(vals)
            id_obj=str(match_one)[len(str(match_one))-1]
            id_obj=new_val[0]

            print("This is matched one id ",id_obj)

            # now changing updating sql query by passing 
            #matching_names_except_this.delete()
            #obj.is_unique = True
            obj.save()
            print(" Data saved Automatically in Amazon")

            print(" Calling mySql_to_CSV to bring change in CSV File without passing id ")
            #self.message_user(request, "This villain is now unique")
            #return HttpResponseRedirect(".")
            print(str(new_val[1:]))
            id_len=len(str(new_val[0]))
            id_len = id_len*(-1)
            print("This is name if Class object",str(match_one)[:id_len-1])
            subprocess.run(['python3', 'mysql_to_csv_v2.py',str(match_one)[:id_len-1],str(new_val[1:]),str(obj.id)])
        return super().response_change(request, obj)


admin.site.register(Machine_detail)
admin.site.register(PLCStatus)

admin.site.register(AlarmSetting)

admin.site.register(MachineOrder)
admin.site.register(Router)


"""
class PLCDataModelForm( forms.ModelForm ):
    plant_1 = forms.CharField( widget=forms.Textarea )
    class Meta:
        model = PLCData

class PLCData_Admin( admin.ModelAdmin ):
    form = PLCDataModelForm
"""


"""
from django.forms import TextInput, Textarea



class PLCIOAdmin(admin.ModelAdmin):
    formfield_overrides = {
        models.CharField: {'widget': Textarea(attrs={'rows':50, 'cols':30})},
        models.IntegerField: {'widget': Textarea(attrs={'rows':50, 'cols':10})},

        models.TextField: {'widget': Textarea(attrs={'rows':4, 'cols':40})},
    }
    list_display = ['name','unit','value']



admin.site.register(PLCIO,PLCIOAdmin)
"""





admin.site.register(User)
admin.site.register(UserMachine)

@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    change_form_template = "admin/change_form2.html"
    def response_change(self, request, obj):
        print("")
        if "_send-message" in request.POST:
            print("sent") 
            """
            content="Machine Sent a message"

            mail=smtplib.SMTP('smtp.gmail.com', 587)
            mail.ehlo()
            mail.starttls()
            sender='ahmadhassan061@gmail.com'
            recipient='develop@kgn.it'
            mail.login('ahmadhassan061@gmail.com','jtjrwpaxovfqsgxv')
            header='To:'+ recipient +'\n'+'From:' \
            +sender+'\n'+'subject:testmail\n'
            content=header+content
            mail.sendmail(sender, recipient, content)
            mail.close()
            """
        
        """
        # Check this if there is problem 
        https://www.youtube.com/watch?v=g_j6ILT-X0k

        """
        return super().response_change(request, obj)

admin.site.register(MessageUser)

"""

class MessageAdmin(admin.ModelAdmin):

    list_display = [ 'get_Message','get_MachineName','get_Users','get_UsersCategory','get_UsersEmail','alarm','description']
    

    list_per_page = 10

    def get_UsersEmail(self, obj):
        return obj.user.email
    def get_Message(self, obj):
        return obj.id
    def get_Users(self, obj):
        return obj.user.name
    def get_UsersCategory(self, obj):
        return obj.user.category
    def get_MachineName(self, obj):
        return obj.machine.machine_Name
#    get_author.short_description = 'Author'
#    get_author.admin_order_field = 'book__author'
admin.site.register(Message,MessageAdmin)

"""



admin.site.register(Alarm)

"""
from .models import Question,KGN_Brand, Machine,Alarm,PLCConfigIO,PLCConfiguration

admin.site.register(Question)
admin.site.register(KGN_Brand)
admin.site.register(Machine)
admin.site.register(Alarm)
admin.site.register(PLCConfiguration)
admin.site.register(PLCConfigIO)

"""


class notificationAdmin(admin.ModelAdmin):
    list_display = ['user','message','is_read']
    list_filter = ['is_read']
    search_fields = ['message']
    list_per_page = 10
    
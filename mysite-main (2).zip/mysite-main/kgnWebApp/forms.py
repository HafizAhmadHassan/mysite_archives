# forms.py
from django import forms
from .models import Machine,PLCStatus,PLCData,PLCIO, Machine_detail

class MachineForm(forms.ModelForm):
    class Meta:
        model = Machine
        fields = [
    'machine_Name',
    'status',
    'waste',
    'linux_Version',
    'start_Available',
    'end_Available',
    'street',
    'postal_Code',
    'province',
    'city',
    'country'
]
  # Include all fields from the Machine model



class PLCStatusForm(forms.ModelForm):
    class Meta:
        model = PLCStatus
        fields = '__all__'  # Include all fields from the Machine model


class PLCDataForm(forms.ModelForm):
    class Meta:
        model = PLCData
        fields = '__all__'  # Include all fields from the Machine model

class PLCIOForm(forms.ModelForm):
    class Meta:
        model = PLCIO
        fields = '__all__'  # Include all fields from the Machine model


class Machine_detailForm(forms.ModelForm):
    class Meta:
        model = Machine_detail
        fields = [
    'sheet_Name',
    'customer_Name',
    'matricola_Bte',
    'matricola_Kgn',
    'horus',
    'matricola_Customer',
    'ip_Router',
    'certificato',
    'codice_GPS',
    'x_GPS',
    'y_GPS',
    'mac_Address',
    'router',
    'sim_provider',
    'sim_Card',
    'pin',
    'puk',
    'imei',
    'note'
] # Include all fields from the Machine model

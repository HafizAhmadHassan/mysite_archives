
from django.urls import path, include

from django.contrib.auth import views as auth_views

from .views import *

urlpatterns = [
    path('api/update-amazon-db/', update_amazon_db, name='update_amazon_db'),
    #path('', index, name='index'),
    path('dash', dashboard, name='dashboard'),
    path('404', page_404, name='page_404'),
    path('profile', page_profile, name='page_profile'),
    path('settings', page_settings, name='page_settings'),
    path('users', page_users, name='page_users'),
    path('tickets', page_tickets, name='page_tickets'),

    path('analytics', page_analytics, name='page_analytics'),
    path('reports', page_reports, name='page_reports'),
    path('register', page_register, name='page_register'),
    path('alarmsettings', alarmsettings, name='alarmsettings'),

    path('details/<int:machine_id>/', machine_details, name='machine_details'),

    path('plcio/<int:machine_id>/', plcio, name='plcio'),
    path('plcdata/<int:machine_id>/', plcdata, name='plcdata'),
    path('plcstatus/<int:machine_id>/', plcstatus, name='plcstatus'),
    path('edit_machine/<int:machine_id>/', edit_machine, name='edit_machine'),

    path('edit_machine_detail/<int:machine_id>/', edit_machine_detail, name='edit_machine_detail'),

    path('edit_plcio/<int:machine_id>/', edit_plcio, name='edit_plcio'),
    path('edit_plcstatus/<int:machine_id>/', edit_plcstatus, name='edit_plcstatus'),
    path('edit_plcdata/<int:machine_id>/', edit_plcdata, name='edit_plcdata'),
    path('machinestatus/<int:machine_id>/', machinestatus, name='machinestatus'),
    path('', index, name='page_login'),

    path('login', page_login, name='index'),
    path('logout/', page_logout, name='page_logout'),
    path('close_ticket/', close_ticket, name='close_ticket'),
    path('gps', gps, name='gps'),
    path('notifications/', notifications, name='notifications'),
    path('ticket/<int:machine_id>/', ticket_form, name='ticket_form'),
    path('ticket/submit/', submit_ticket, name='submit_ticket'),
    path('ticket/sent/', email_acknowledgement, name='email_acknowledgement'),
    path('myapi/', include('myapi.urls')),  # Or whatever path you want


]
